let money = 1000;
let eco = 0;
let round = 0;
const shop = document.getElementById("shop");
const messageBox = document.getElementById("message");

// 四組商品，每組二選一
const groups = [
  [
    { name: "Disposable Correction Tape", cost: 20, eco: -5, desc: "Cheap and convenient, not eco-friendly." },
    { name: "Reusable Correction Tape", cost: 40, eco: 10, desc: "Refillable, good for the Earth." }
  ],
  [
    { name: "Plastic Building Blocks", cost: 500, eco: -15, desc: "Fun but made of plastic." },
    { name: "Wooden Building Blocks", cost: 700, eco: 20, desc: "Made of wood, eco-friendly." }
  ],
  [
    { name: "Individually Wrapped Egg Rolls", cost: 400, eco: -10, desc: "Lots of packaging waste." },
    { name: "Canned Egg Rolls", cost: 200, eco: 15, desc: "Less packaging, better for Earth." }
  ],
  [
    { name: "Bubble Tea in Plastic Cup", cost: 70, eco: -8, desc: "Convenient, but uses plastic." },
    { name: "Bubble Tea in Reusable Cup", cost: 60, eco: 12, desc: "Bring your own cup, eco-friendly." }
  ]
];

function render() {
  // 1. 更新狀態欄
  document.getElementById("money").innerText = money;
  document.getElementById("eco").innerText = eco;

  // 2. 檢查遊戲是否結束
  // 如果所有回合都完成 OR 剩下的錢買不起當前回合最便宜的商品
  const isGameOverByRound = round >= groups.length;
  let isGameOverByMoney = false;
  if (!isGameOverByRound) {
      isGameOverByMoney = money < Math.min(...groups[round].map(item => item.cost));
  }
  
  if (isGameOverByRound || isGameOverByMoney) {
    let result = "";
    let color = "";
    if (eco >= 50) {
      result = "🎉 Eco Hero! You really care for the planet!";
      color = "#4caf50";
    }
    else if (eco >= 20) {
      result = "🙂 Eco Learner! You are learning to make eco-friendly choices.";
      color = "#ff9800";
    }
    else {
      result = "⚠️ Eco Needs Help! Try to choose more eco-friendly items next time.";
      color = "#f44336";
    }

    shop.innerHTML = `
      <div class="card" style="grid-column: 1 / -1; text-align: center; border-color: ${color};">
        <h2>Game Over</h2>
        <p>Final Money left: 💰 **${money}**</p>
        <p>Final Eco Points: 🌍 **${eco}**</p>
        <h3 style="color: ${color};">${result}</h3>
      </div>
    `;
    messageBox.style.color = color;
    messageBox.innerText = "Game Ended!";
    return;
  }

  // 3. 渲染當前回合商品
  shop.innerHTML = "";
  // 更新訊息區顯示當前回合
  messageBox.style.color = '#1976d2';
  messageBox.innerText = `Round ${round + 1} of ${groups.length}: Make your choice!`;
  
  groups[round].forEach((item, index) => {
    const card = document.createElement("div");
    card.className = "card";
    const canBuy = money >= item.cost;
    
    // 判斷 eco 點數是加分還是扣分，顯示不同顏色
    const ecoColor = item.eco > 0 ? '#4caf50' : '#f44336'; 
    
    // 將 chooseItem 設為全域函數，讓 HTML 知道如何調用它
    window.chooseItem = chooseItem; 

    card.innerHTML = `
      <h3>${item.name}</h3>
      <p>${item.desc}</p>
      <p>
        💰 **${item.cost}** ｜ 
        🌍 <span style="color:${ecoColor};">${item.eco > 0 ? "+" : ""}${item.eco}</span>
      </p>
      <button class="${canBuy ? "" : "disabled"}" ${canBuy ? "" : "disabled"} onclick="chooseItem(${index})">Choose This</button>
    `;
    shop.appendChild(card);
  });
}

function chooseItem(index) {
  const item = groups[round][index];
  
  if (money < item.cost) {
    messageBox.style.color = '#d32f2f';
    messageBox.innerText = `Cannot afford ${item.name}! Need 💰${item.cost}, only have 💰${money}.`;
    return;
  }
  
  money -= item.cost;
  eco += item.eco;
  round++;
  
  // 更新訊息區顯示結果
  messageBox.style.color = '#00796b';
  messageBox.innerHTML = `You chose: **${item.name}**. You gained 🌍 **${item.eco}** points.`;

  // 短暫延遲後重新渲染下一回合，讓用戶有時間看到結果
  setTimeout(render, 500); 
}

// 初始化畫面
render();
