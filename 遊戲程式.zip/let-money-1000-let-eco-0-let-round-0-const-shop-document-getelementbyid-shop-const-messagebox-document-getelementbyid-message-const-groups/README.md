# let money = 1000; let eco = 0; let round = 0; const shop = document.getElementById("shop"); const messageBox = document.getElementById("message");  // 四組商品，每組二選一 const groups = [   [     { 

A Pen created on CodePen.

Original URL: [https://codepen.io/pcbucptg-the-encoder/pen/MYydLqE](https://codepen.io/pcbucptg-the-encoder/pen/MYydLqE).

